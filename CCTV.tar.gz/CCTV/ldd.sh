    #!/bin/sh  
      
    exe="Qt-WatchDog-CCTV" #发布的程序名称  
    des="/home/tjp/Git/build-Qt-WatchDog-CCTV-Desktop_Qt_5_9_1_GCC_64bit-Release/CCTV" #你的路径  
      
    deplist=$(ldd $exe | awk  '{if (match($3,"/")){ printf("%s "),$3 } }')  
    cp $deplist $des  
